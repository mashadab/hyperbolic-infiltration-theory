#Validation with Beven, Selkar and Childs data
#Mohammad Afzal Shadab
#Date modified: 08/21/21

import sys
sys.path.insert(1, './../')
from supporting_tools import *

from scipy.integrate import solve_ivp
import scipy.optimize as opt
from matplotlib import cm         #color map
from scipy.optimize import fsolve
from math import gamma
from scipy.integrate import quad
import mpmath as mp

plt.rcParams.update({'font.family': "Serif"})

brown  = [181/255 , 101/255, 29/255]
red    = [255/255 ,255/255 ,255/255 ]
blue   = [ 30/255 ,144/255 , 255/255 ]
green  = [  0/255 , 166/255 ,  81/255]
orange = [247/255 , 148/255 ,  30/255]
purple = [102/255 ,  45/255 , 145/255]
brown  = [155/255 ,  118/255 ,  83/255]
tan    = [199/255 , 178/255 , 153/255]
gray   = [100/255 , 100/255 , 100/255]



def case(i):
        switcher={
                #Separate regions
                #Region 2: Three phase region
                3: [[0.36,0.36],[0.0,0.2]], #Contact discontinuity C1  (working)

             }
        return switcher.get(i,"Invalid Case")


#parameters
case_no =  3              #case number
simulation_name = f'case{case_no}_hyperbolic_Richards_'
m = 100 #Cozeny-Karman coefficient for numerator K = K0 (1-phi_i)^m
n = 1 #Corey-Brooks coefficient krw = krw0 * sw^n
s_wr = 0.0 #Residual water saturation
s_gr = 0.0 #Residual gas saturation

#test details
[u_L,u_R] = case(case_no) #left and right states
[C_L,phi_L] = u_L #water sat, porosity
[C_R,phi_R] = u_R #water sat, porosity
C_R = s_gr*phi_R #resetting the saturation

#temporal
tmax = 1 #time scaling with respect to fc/z0
z0 = 1   #point specified for exponential variation #m
Nt = 100000
t  = np.linspace(0,tmax,Nt+1)

#Non-dimensional permeability: Harmonic mean
def f_Cm(phi,m):
    fC = np.zeros_like(phi)        
    fC = phi**m / phi_L**m           #Power law porosity
    return fC

#Rel perm of water: Upwinded
def f_Cn(C,phi,n):
    fC = np.zeros_like(phi)
    fC = ((C/phi-s_wr)/(1-s_gr-s_wr))**n    #Power law rel perm
    #fC[C>=phi]  = 0.0      
    return fC

#spatial
Grid_xmin = -1; Grid_xmax =1.0; Grid_Nx = 400
Grid_dx = (Grid_xmax - Grid_xmin) / Grid_Nx
Grid_xc = np.linspace(Grid_xmin+Grid_dx/2, Grid_xmax-Grid_dx/2,Grid_Nx)


R_array =[1] #np.linspace(0.51,0.640000000000005,10) #[0.640000000000001]#

Blues = cm.get_cmap('Blues', len(R_array)+2)

fig = plt.figure(figsize=(8,8) , dpi=100)

for count,R in enumerate(R_array):
    def func_R2phil_l(C_L):
        return (f_Cm(np.array([phi_L]),m)[0]*f_Cn(np.array([C_L]),np.array([phi_L]),n))[0] - R 
    #C_L = opt.fsolve(func_R2phil_l,0.01)[0]    
    C_L = phi_L - 0.00000001
    R = f_Cn(np.array([C_L]),np.array([phi_L]),n)[0]
    tf = 0
    tp = 0
    ytop = 0
    ybot = 0
 
    def qs(zu,zl):
        return (m/z0*(zu-zl))/(np.exp(m*zu/z0)-np.exp(m*zl/z0))
        #return (1/z0*(zu-zl))/(np.exp(zu/z0)-np.exp(zl/z0))
    
    def rhs(t, y):     
        return [ 0, \
                  qs(y[0],y[1])/(phi_L*np.exp(-y[1]/z0)*(1-s_gr-s_wr))]
                 
    #Infiltration rate with time
    t1 = np.linspace(tp,1,10000)
    res= solve_ivp(rhs, (t1[0],t1[-1]), [ytop,ybot+1e-14],t_eval=t1)
    y  = res.y

#Beven 1984 parameters
fc = 16.65 #Saturated hydraulic conductivity at the surface m/h
ff = 1.888#1.888 #1/m #3.3
depth = m/ff #because of our case
print(np.linalg.norm(((1 - s_gr - s_wr)*(1-np.exp(-y[1]/z0)))))
print(np.linalg.norm(t1/fc))
    
I = phi_L*depth*(1 - s_gr - s_wr)*(1-np.exp(-y[1]/z0))

Childs   = np.genfromtxt('./Beven_Childs/Childs.csv', delimiter=',')
Bevenpt2 = np.genfromtxt('./Beven_Childs/Beven_C0.2m.csv', delimiter=',')
Bevenpt6 = np.genfromtxt('./Beven_Childs/Beven_C0.6m.csv', delimiter=',')

plt.plot(t1*depth/fc,R*fc*(t1*depth/fc),c=blue,label='$R \star t$')
plt.plot(t1*depth/fc,I,'k-',label='Present')
#plt.plot(t1*depth/fc,y[1]*depth,'k-',label='Present')
plt.plot(Childs[:,0],Childs[:,1],'ro',label='Childs (1969)',markersize=15)
plt.ylabel(r'Cumulative infiltration, $I_c$ [m]')
plt.xlabel(r'$t$ [hr]')
plt.xlim([0, 0.127])
plt.ylim([0,0.7])


tt_array = np.linspace(0,0.127,100)
II = np.empty(100)
Selker_II = np.empty(100)
for count,tt in enumerate(tt_array):
    def Beven_equations(II):
        dtheta = 0.36
        n = 150
        sum_ = 0
        for m in range(1,n+1):
            sum_ = sum_ + ((II*ff/dtheta)**m) /(gamma(m+1) * m)
        return dtheta/(fc * ff) * sum_ - tt
    II[count] =  fsolve(Beven_equations, (0.1))
    
    dtheta = 0.36
    beta   = 1.008
    Ko     = 19.525
    Psi_wfo= -0.059808

    def Selkar_equation(zz):
        return tt - dtheta/(2*beta*Ko)* quad(lambda z:(1-np.exp(2*beta*z))/(Psi_wfo*np.exp(beta*z)-z), 0, zz)[0]       

    Selker_II[count] =  fsolve(Selkar_equation, (0.1))[0] * dtheta

plt.plot(tt_array,II,'r--',label='Beven (1984), C=0m')
plt.plot(Bevenpt2[:,0],Bevenpt2[:,1],'--',c=brown,label='Beven (1984), C=0.2m')
plt.plot(Bevenpt6[:,0],Bevenpt6[:,1],'b--',label='Beven (1984), C=0.6m')
plt.plot(tt_array,Selker_II,'g--',label='Selker (1999)')
plt.legend(loc='lower right', shadow=False, fontsize='small')
plt.tight_layout(pad=1, w_pad=0.8, h_pad=1)
plt.savefig(f"../Figures/Beven_exponential_R_infiltration_shock_{simulation_name}_Nx{Grid_Nx}_CL{C_L}CR{C_R}_phiL{phi_L}phiR{phi_R}__tf{t[len(t)-1]}.pdf")


