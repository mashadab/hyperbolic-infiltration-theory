#Coding the Richard's equation for water two-layer (HYDRUS)
#Mohammad Afzal Shadab
#Date modified: 07/05/21

import sys
sys.path.insert(1, './../../')

from supporting_tools import *

def case(i):
        switcher={
                #Separate regions
                #Region 2: Three phase region
                3: [[0.3783,0.43],[0.0,0.1]]#[[0.4,0.5],[0.0,0.2]], #Contact discontinuity C1  (working)   
             }
        return switcher.get(i,"Invalid Case")

#Hydrus data
f = np.loadtxt('../two_layer_infiltration_final/infiltration_rate.out')
pt0 = np.loadtxt('profile0pt0.out')
profile0pt2536 = np.loadtxt('profile0pt2536.out')
profile0pt4469 = np.loadtxt('profile0pt4469.out')
profile0pt4800 = np.loadtxt('profile0pt4800.out')
profile0pt5241 = np.loadtxt('profile0pt5241.out')
profile0pt7069 = np.loadtxt('profile0pt7069.out')

phi_u = 0.43*np.ones((200,1))
phi_l = 0.1*np.ones((201,1))

phi_hydrus = np.concatenate((phi_u,phi_l), axis=0)

#############
#parameters
case_no =  3              #case number
Grid_xmin = -1; Grid_xmax =1.0; Grid_Nx = 400
Grid_dx = (Grid_xmax - Grid_xmin) / Grid_Nx
Grid_xc = np.linspace(Grid_xmin+Grid_dx/2, Grid_xmax-Grid_dx/2,Grid_Nx)
simulation_name = f'case{case_no}_hyperbolic_Richards_'
m = 3      #Cozeny-Karman coefficient for numerator K = K0 (1-phi_i)^m
n = 7.15306#Corey-Brooks coefficient krw = krw0 * sw^n
s_wr = 0.0 #Residual water saturation
s_gr = 0.0 #Residual gas saturation

#test details
[u_L,u_R] = case(case_no) #left and right states
[C_L,phi_L] = u_L #water sat, porosity
[C_R,phi_R] = u_R #water sat, porosity
C_R = s_gr*phi_R #resetting the saturation
xm = 0.0 #the location of jump
phi = phi_L*np.ones((Grid_Nx,1))
phi[Grid_xc>xm,:] = phi_R  

#temporal
tmax = 1.5 #5.7#6.98  #time scaling with respect to fc

t = np.linspace(0,tmax,1000)
t_interest = [0,0.5,0.9457496575584368 +0.002,1.01856,1.112236563557746,tmax]  #swr,sgr=0
t = np.sort(np.unique(np.append(t,t_interest)))

#Non-dimensional permeability: Harmonic mean
def f_Cm(phi,m):
    fC = np.zeros_like(phi)        
    fC = (phi**m) / (phi_L**m)           #Power law porosity
    return fC

#Rel perm of water: Upwinded
def f_Cn(C,phi,n):
    fC = np.zeros_like(phi)
    fC = ((C/phi-s_wr)/(1-s_gr-s_wr))**n    #Power law rel perm   
    return fC

#####RUN FROM HERE FOR ANALYTICAL
# %% Define derivative function

def rhs(t, y): 
    return [((y[0]-y[1])/(y[0]/f_Cm(np.array([phi_L]),m)-y[1]/f_Cm(np.array([phi_R]),m))-f_Cm(np.array([phi_L]),m)*f_Cn(np.array([C_L]),np.array([phi_L]),n))[0]/(phi_L*(1-s_gr)-C_L), \
            ((y[0]-y[1])/(y[0]/f_Cm(np.array([phi_L]),m)-y[1]/f_Cm(np.array([phi_R]),m))-f_Cm(np.array([phi_R]),m)*f_Cn(np.array([C_R]),np.array([phi_R]),n))[0]/(phi_R*(1-s_gr)-C_R)]
res = solve_ivp(rhs, (0, t[-1]), [-1e-14,1e-15],t_eval=t)
y   = res.y
qs_int = (y[0]-y[1])/(y[0]/f_Cm(np.array([phi_L]),m)-y[1]/f_Cm(np.array([phi_R]),m))
s_l_int = (qs_int -f_Cm(np.array([phi_L]),m)*f_Cn(np.array([C_L]),np.array([phi_L]),n))/(phi_L*(1-s_gr)-C_L)
s_r_int = (qs_int -f_Cm(np.array([phi_R]),m)*f_Cn(np.array([C_R]),np.array([phi_R]),n))/(phi_R*(1-s_gr)-C_R)


aa = phi_L/phi_R*(1-C_L/phi_L-s_gr)/(1-C_R/phi_R-s_gr)*(1- f_Cm(np.array([phi_R]),m) * f_Cn(np.array([C_R]),np.array([phi_R]),n) / f_Cm(np.array([phi_L]),m))
bb =-phi_L/phi_R*(1-C_L/phi_L-s_gr)/(1-C_R/phi_R-s_gr)*(1- f_Cm(np.array([phi_R]),m) * f_Cn(np.array([C_R]),np.array([phi_R]),n) / f_Cm(np.array([phi_R]),m)) - (1 - f_Cm(np.array([phi_L]),m) * f_Cn(np.array([C_L]),np.array([phi_L]),n) / f_Cm(np.array([phi_L]),m))
cc = 1 - f_Cm(np.array([phi_L]),m) * f_Cn(np.array([C_L]),np.array([phi_L]),n) / f_Cm(np.array([phi_R]),m)

k = (-bb-np.sqrt(bb**2-4*aa*cc))/(2*aa)

def qs(x):
    return (x-1)/(x/f_Cm(np.array([phi_L]),m) - 1/f_Cm(np.array([phi_R]),m))

s_l_analy =(qs(k) - f_Cm(np.array([phi_L]),m)*f_Cn(np.array([C_L]),np.array([phi_L]),n))[0]/(phi_L*(1-s_gr-C_L/phi_L))
s_r_analy =(qs(k) - f_Cm(np.array([phi_R]),m)*f_Cn(np.array([C_R]),np.array([phi_R]),n))[0]/(phi_R*(1-C_R/phi_R-s_gr))


# First set up the figure, the axis

fig = plt.figure(figsize=(15,7.5) , dpi=100)
ax1 = fig.add_subplot(1, 6, 1)
ax2 = fig.add_subplot(1, 6, 2)
ax3 = fig.add_subplot(1, 6, 3)
ax4 = fig.add_subplot(1, 6, 4)
ax5 = fig.add_subplot(1, 6, 5)
ax6 = fig.add_subplot(1, 6, 6)

#ax1.set_xlim([T_top-dt_a-dt_d-273.16,T_top+dt_a+dt_d-273.16])
#ax1.set_ylim(70, grid.ymax)
#ax1.set_ylim([grid.ymin,grid.ymax])
ax1.set_ylabel(r'Dimensionless depth')
ax1.set_ylim([Grid_xmax,Grid_xmin])
ax1.set_xlim([0,1])

ax2.set_xlim([0,1])
ax2.set_ylim([Grid_xmax,Grid_xmin])
ax2.axes.yaxis.set_visible(False)
#ax2.set_ylim(70, grid.ymax)
#ax2.set_ylabel(r'$y[m]$')
ax4.set_xlabel(r'Volume fractions $\phi$')
#ax2.xaxis.set_label_coords(0.5, -0.2)
#ax2.yaxis.set_label_coords(-0.1, 0.5)

ax3.set_xlim([0,1])
ax3.axes.yaxis.set_visible(False)
ax3.set_ylim([Grid_xmax,Grid_xmin])
#ax3.set_ylim([grid.ymin,grid.ymax])

ax4.set_xlim([0,1])
ax4.axes.yaxis.set_visible(False)
ax4.set_ylim([Grid_xmax,Grid_xmin])

ax5.set_xlim([0,1])
ax5.axes.yaxis.set_visible(False)
ax5.set_ylim([Grid_xmax,Grid_xmin])

ax6.set_xlim([0,1])
ax6.axes.yaxis.set_visible(False)
ax6.set_ylim([Grid_xmax,Grid_xmin])

manager = plt.get_current_fig_manager()
manager.window.showMaximized()

Sf = (f_Cm(np.array([phi_L]),m)[0]*f_Cn(np.array([C_L]),np.array([phi_L]),n))[0] / (phi_L*(C_L/phi_L - s_wr))
tf = (xm - Grid_xmin)/Sf
tp = tf + (Grid_xmin-xm)/s_l_analy

xf = Grid_xmin + Sf*t_interest[0]#(phi_L**m*(C_L/phi_L)**n)/(C_L)*0   #at t = 0
S_w_analy_int = (1-s_gr)*np.ones((Grid_Nx,1))
S_w_analy_int[Grid_xc<=xf] = C_L/phi_L
S_w_analy_int[Grid_xc>=xf] = C_R/phi_R

S_w_analy_int_combined = []
S_w_analy_int_combined = S_w_analy_int.copy()

ax1.fill_betweenx(Grid_xc,1, facecolor=red,label=r'$\phi_g$')
ax1.fill_betweenx(Grid_xc,(1-phi+phi*S_w_analy_int)[:,0], facecolor=blue,label=r'$\phi_w$')
ax1.fill_betweenx(Grid_xc,(1-phi)[:,0], facecolor=brown,label=r'$\phi_s$')

xf = Grid_xmin + Sf*t_interest[1]
S_w_analy_int = (1-s_gr)*np.ones((Grid_Nx,1))
S_w_analy_int[Grid_xc<=xf] = C_L/phi_L
S_w_analy_int[Grid_xc>=xf] = C_R/phi_R

S_w_analy_int_combined = np.hstack([S_w_analy_int_combined,S_w_analy_int])

ax2.fill_betweenx(Grid_xc,1, facecolor=red,label=r'$\phi_g$')
ax2.fill_betweenx(Grid_xc,(1-phi+phi*S_w_analy_int)[:,0], facecolor=blue,label=r'$\phi_w$')
ax2.fill_betweenx(Grid_xc,(1-phi)[:,0], facecolor=brown,label=r'$\phi_s$')


res.y[0,0] =  s_l_analy*(t_interest[2]-tf)
res.y[1,0] =  s_r_analy*(t_interest[2]-tf)
S_w_analy_int = (1-s_gr)*np.ones((Grid_Nx,1))
S_w_analy_int[Grid_xc<=res.y[0,0]] = C_L/phi_L
S_w_analy_int[Grid_xc>=res.y[1,0]] = C_R/phi_R

S_w_analy_int_combined = np.hstack([S_w_analy_int_combined,S_w_analy_int])

ax3.fill_betweenx(Grid_xc,1, facecolor=red,label=r'$\phi_{gas}$')
ax3.fill_betweenx(Grid_xc,(1-phi+phi*S_w_analy_int)[:,0], facecolor=blue,label=r'$\phi_{water}$')
ax3.fill_betweenx(Grid_xc,(1-phi)[:,0], facecolor=brown,label=r'$\phi_{soil}$')

res.y[0,0] =  s_l_analy*(t_interest[3]-tf)
res.y[1,0] =  s_r_analy*(t_interest[3]-tf)
S_w_analy_int = (1-s_gr)*np.ones((Grid_Nx,1))
S_w_analy_int[Grid_xc<=res.y[0,0]] = C_L/phi_L
S_w_analy_int[Grid_xc>=res.y[1,0]] = C_R/phi_R

S_w_analy_int_combined = np.hstack([S_w_analy_int_combined,S_w_analy_int])

ax4.fill_betweenx(Grid_xc,1, facecolor=red,label=r'$\phi_g$')
ax4.fill_betweenx(Grid_xc,(1-phi+phi*S_w_analy_int)[:,0], facecolor=blue,label=r'$\phi_w$')
ax4.fill_betweenx(Grid_xc,(1-phi)[:,0], facecolor=brown,label=r'$\phi_s$')

res.y[0,0] =  s_l_analy*(tp-tf)
res.y[1,0] =  s_r_analy*(tp-tf)
S_w_analy_int = (1-s_gr)*np.ones((Grid_Nx,1))
S_w_analy_int[Grid_xc<=res.y[0,0]] = C_L/phi_L
S_w_analy_int[Grid_xc>=res.y[1,0]] = C_R/phi_R

S_w_analy_int_combined = np.hstack([S_w_analy_int_combined,S_w_analy_int])

ax5.fill_betweenx(Grid_xc,1, facecolor=red,label=r'$\phi_{gas}$')
ax5.fill_betweenx(Grid_xc,(1-phi+phi*S_w_analy_int)[:,0], facecolor=blue,label=r'$\phi_{water}$')
ax5.fill_betweenx(Grid_xc,(1-phi)[:,0], facecolor=brown,label=r'$\phi_{soil}$')

ytop = res.y[0,0]
ybot = res.y[1,0]

def rhs(t, y): 
    return [0, \
            ((y[0]-y[1])/(y[0]/f_Cm(np.array([phi_L]),m)-y[1]/f_Cm(np.array([phi_R]),m))-f_Cm(np.array([phi_R]),m)*f_Cn(np.array([C_R]),np.array([phi_R]),n))[0]/(phi_R*(1-s_gr)-C_R)]

res = solve_ivp(rhs, (0, t_interest[5]-tp), [ytop,ybot],t_eval=[t_interest[5]-tp])
S_w_analy_int = (1-s_gr)*np.ones((Grid_Nx,1))
S_w_analy_int[Grid_xc<=res.y[0,0]] = C_L/phi_L
S_w_analy_int[Grid_xc>=res.y[1,0]] = C_R/phi_R

S_w_analy_int_combined = np.hstack([S_w_analy_int_combined,S_w_analy_int])

ax6.fill_betweenx(Grid_xc,1, facecolor=red,label=r'$\phi_{gas}$')
ax6.fill_betweenx(Grid_xc,(1-phi+phi*S_w_analy_int)[:,0], facecolor=blue,label=r'$\phi_{water}$')
ax6.fill_betweenx(Grid_xc,(1-phi)[:,0], facecolor=brown,label=r'$\phi_{soil}$')

ax1.legend(loc='lower left', shadow=False, fontsize='medium')

ax1.set_title(r'$t^*$=%.2f'%t_interest[0])
ax2.set_title(r'%.2f'%t_interest[1])
ax3.set_title(r'%.2f ($t_s$)'%t_interest[2])
ax4.set_title(r'%.2f'%t_interest[3])
ax5.set_title(r'%.2f ($t_p$)'%tp)
ax6.set_title(r'%.2f'%t_interest[5])
plt.subplots_adjust(wspace=0.25, hspace=0)
plt.savefig(f"shock_Nx{Grid_Nx}_CL{C_L}CR{C_R}_phiL{phi_L}phiR{phi_R}m{m}_n{n}.pdf")


#Saturated flux with time

t1 = np.linspace(tf,tp,1000)
qs1 = qs(k)*np.ones_like(t1)

def rhs(t, y): 
    return [0, \
            ((y[0]-y[1])/(y[0]/f_Cm(np.array([phi_L]),m)-y[1]/f_Cm(np.array([phi_R]),m))-f_Cm(np.array([phi_R]),m)*f_Cn(np.array([C_R]),np.array([phi_R]),n))[0]/(phi_R*(1-s_gr)-C_R)]

t2 = np.linspace(tp,10,1000)
res= solve_ivp(rhs, (t2[0],t2[-1]), [ytop,ybot],t_eval=t2)
y  = res.y

qs2 = (y[0]-y[1])/(y[0]/f_Cm(np.array([phi_L]),m) - y[1]/f_Cm(np.array([phi_R]),m))


fig = plt.figure(figsize=(8,8) , dpi=100)
plot = plt.plot(t1,qs1/f_Cm(np.array([phi_L]),m),'r-')
plot = plt.plot(t2,qs2/f_Cm(np.array([phi_L]),m),'r-')
plt.vlines(tf, 0, qs(k)/f_Cm(np.array([phi_L]),m), colors='k', linestyles='--')
plt.vlines(tp, 0, qs(k)/f_Cm(np.array([phi_L]),m), colors='k', linestyles='--')
plt.ylabel(r'$q_s/f_c$')
plt.xlabel(r'$tf_c/z_0$')
plt.ylim([0.99*(np.min(qs2)//f_Cm(np.array([phi_L]),m)),1.05*(qs(k)/f_Cm(np.array([phi_L]),m))])
plt.tight_layout(pad=0.4, w_pad=0.5, h_pad=1.0)
plt.savefig(f"qsvsT_shock_{simulation_name}_Nx{Grid_Nx}_CL{C_L}CR{C_R}_phiL{phi_L}phiR{phi_R}__tf{t[len(t)-1]}.pdf")


#Infiltration rate with time
t0 = np.linspace(0,tf,1000)
qs0 = (f_Cm(np.array([phi_L]),m)*f_Cn(np.array([C_L]),np.array([phi_L]),n))* np.ones_like(t0)

t1 = np.linspace(tf,tp,1000)
qs1 = (f_Cm(np.array([phi_L]),m)*f_Cn(np.array([C_L]),np.array([phi_L]),n))*np.ones_like(t1)

def rhs(t, y): 
    return [0,((y[0]-y[1])/(y[0]/f_Cm(np.array([phi_L]),m)-y[1]/f_Cm(np.array([phi_R]),m))-f_Cm(np.array([phi_R]),m)*f_Cn(np.array([C_R]),np.array([phi_R]),n))[0]/(phi_R*(1-s_gr)-C_R)]

t2 = np.linspace(tp,10,1000)
res= solve_ivp(rhs, (t2[0],t2[-1]), [ytop,ybot],t_eval=t2)
y  = res.y

qs2 = (y[0]-y[1])/(y[0]/f_Cm(np.array([phi_L]),m) - y[1]/f_Cm(np.array([phi_R]),m))

T  = np.concatenate([t0,t1,t2])
QS = np.concatenate([qs0,qs1,qs2])
fig = plt.figure(figsize=(8,8) , dpi=100)
plot = plt.plot(T,QS/f_Cm(np.array([phi_L]),m),'r-',label='Analytical')
plt.plot(f[:,0]*106.1/50,f[:,3]/(-106.1),'b--',label='Hydrus')
plt.vlines(tf, 0, qs0[0]/f_Cm(np.array([phi_L]),m), colors=gray, linestyles='--')
plt.vlines(tp, 0, qs0[0]/f_Cm(np.array([phi_L]),m), colors=gray, linestyles='--')
plt.hlines(f_Cm(np.array([phi_R]),m), np.min(T), np.max(T), colors=gray, linestyles='--')
plt.ylabel(r'$I(t)/f_c$')
plt.xlabel(r'$t^*$')
plt.xlim([np.min(T), np.max(T)])
plt.legend(loc='best', shadow=False, fontsize='medium')
plt.ylim([0,round(np.max(QS),1)+0.1])
plt.tight_layout(pad=0.4, w_pad=0.5, h_pad=1.0)
plt.savefig(f"ICvsT_shock_{simulation_name}_Nx{Grid_Nx}_CL{C_L}CR{C_R}_phiL{phi_L}phiR{phi_R}__tf{t[len(t)-1]}.pdf")

#plt.plot(t[0:-1],qs_sol,'k-')
plt.xlim([np.min(T), tmax])
plt.ylim([0,round(np.max(QS),1)+0.1])
plt.tight_layout(pad=0.4, w_pad=0.5, h_pad=1.0)
plt.savefig(f"cut_ICvsT_shock_{simulation_name}_Nx{Grid_Nx}_CL{C_L}CR{C_R}_phiL{phi_L}phiR{phi_R}__tf{t[len(t)-1]}.pdf")

# First set up the figure, the axis

fig = plt.figure(figsize=(15,7.5) , dpi=100)
ax1 = fig.add_subplot(1, 6, 1)
ax2 = fig.add_subplot(1, 6, 2)
ax3 = fig.add_subplot(1, 6, 3)
ax4 = fig.add_subplot(1, 6, 4)
ax5 = fig.add_subplot(1, 6, 5)
ax6 = fig.add_subplot(1, 6, 6)

ax1.set_ylabel(r'Dimensionless depth $z/z_0$')
ax1.set_ylim([Grid_xmax,Grid_xmin+0.05])
ax1.set_xlim([-0.05,1.05])

ax2.set_xlim([-0.05,1.05])
ax2.set_ylim([Grid_xmax,Grid_xmin+0.05])
ax2.axes.yaxis.set_visible(False)
ax4.set_xlabel(r'Water saturation $s_w$')

ax3.set_xlim([-0.05,1.05])
ax3.axes.yaxis.set_visible(False)
ax3.set_ylim([Grid_xmax,Grid_xmin+0.05])

ax4.set_xlim([-0.05,1.05])
ax4.axes.yaxis.set_visible(False)
ax4.set_ylim([Grid_xmax,Grid_xmin+0.05])

ax5.set_xlim([-0.05,1.05])
ax5.axes.yaxis.set_visible(False)
ax5.set_ylim([Grid_xmax,Grid_xmin+0.05])

ax6.set_xlim([-0.05,1.05])
ax6.axes.yaxis.set_visible(False)
ax6.set_ylim([Grid_xmax,Grid_xmin+0.05])

manager = plt.get_current_fig_manager()
manager.window.showMaximized()

ax1.plot(S_w_analy_int_combined[:,0],Grid_xc , c = 'k',linestyle='--',label=r'A')
ax1.plot(pt0[:,3]/phi_hydrus[:,0],1-pt0[:,1]/(-50),'b--',label=r'H')
ax1.legend(loc='lower left', shadow=False, fontsize='medium')

ax2.plot(S_w_analy_int_combined[:,1],Grid_xc , c = 'k',linestyle='--',label=r'Analytical')
ax3.plot(S_w_analy_int_combined[:,2],Grid_xc , c = 'k',linestyle='--',label=r'Analytical')
ax4.plot(S_w_analy_int_combined[:,3],Grid_xc , c = 'k',linestyle='--',label=r'Analytical')
ax5.plot(S_w_analy_int_combined[:,4],Grid_xc , c = 'k',linestyle='--',label=r'Analytical')
ax6.plot(S_w_analy_int_combined[:,5],Grid_xc , c = 'k',linestyle='--',label=r'Analytical')

ax2.plot(profile0pt2536[:,3]/phi_hydrus[:,0],profile0pt2536[:,1]/(-50)-1,'b--',label=r'H')
ax3.plot(profile0pt4469[:,3]/phi_hydrus[:,0],profile0pt4469[:,1]/(-50)-1,'b--',label=r'H')
ax4.plot(profile0pt4800[:,3]/phi_hydrus[:,0],profile0pt4800[:,1]/(-50)-1,'b--',label=r'H')
ax5.plot(profile0pt5241[:,3]/phi_hydrus[:,0],profile0pt5241[:,1]/(-50)-1,'b--',label=r'H')
ax6.plot(profile0pt7069[:,3]/phi_hydrus[:,0],profile0pt7069[:,1]/(-50)-1,'b--',label=r'H')

ax1.set_title(r'$t^*$=%.2f'%t_interest[0])
ax2.set_title(r'%.2f'%t_interest[1])
ax3.set_title(r'%.2f ($t_s$)'%t_interest[2])
ax4.set_title(r'%.2f'%t_interest[3])
ax5.set_title(r'%.2f ($t_p$)'%tp)
ax6.set_title(r'%.2f'%t_interest[5])
plt.subplots_adjust(wspace=0.25, hspace=0)
plt.savefig(f"swvsZpanelshock_Nx{Grid_Nx}_CL{C_L}CR{C_R}_phiL{phi_L}phiR{phi_R}m{m}_n{n}.pdf")
