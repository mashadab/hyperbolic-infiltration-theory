"""
Plotting
Author: Mohammad Afzal Shadab
Email: mashadab@utexas.edu
Date modified: 04/06/2021
"""

#Importing required libraries
from IPython import get_ipython
get_ipython().magic('reset -sf')#for clearing everything
get_ipython().run_line_magic('matplotlib', 'qt') #for plotting in separate window
import pandas as pd

import numpy as np              #import np library
from scipy.fftpack import fft, fftfreq
import matplotlib.pyplot as plt #library for plotting
plt.rcParams.update({'font.size': 22})

table1 = pd.read_excel(r'Devon_for_Afzal_AWS.xlsx')    #loading the file

TT = table1[1.781].values
tt = table1[1600].values
yy = table1[2001].values
dd = table1[188].values

# Number of sample points
n = len(TT)#70000#60235 #147893
TT = TT[0:n]
N = n
# sample spacing
T = 1 #hours
x = np.linspace(0.0, N*T, N, endpoint=False)
yf= fft(TT)
xf = fftfreq(N, T)[:N//2]

Tmean = np.mean(TT)

ax = plt.figure(figsize=(15,7.5) , dpi=100)
plt.semilogy(xf[1:N//2], 2.0/N * np.abs(yf[1:N//2]), '-b')
plt.ylabel(r'$Amplitude \quad [^oC]$')
plt.xlabel(r'$Frequency \quad [hour^{-1}]$')
plt.title(f"Tmean=%0.2f C, Elevation: 1317m, Year: 2001-15, {N} hour-separated readings"%Tmean)

#x = [1.1621150493e-4,4.1670125342e-2,8.3107827e-2]
#y = [1.4619e1,9.009e-1,1.15571e-1]
x = [1.15683245e-4,4.16595782e-2,8.33259613e-2]
y = [14.2027,0.642817,0.0938]
plt.plot(x, y, 'kX')

for i_x, i_y in zip(x, y):
    plt.text(i_x, i_y, '({}, {})'.format(i_x, i_y))

plt.grid()
plt.show()
manager = plt.get_current_fig_manager()
manager.window.showMaximized()
plt.tight_layout(pad=0.4, w_pad=0.5, h_pad=1.0)
plt.savefig(f'FFT_David_lowest.pdf',bbox_inches='tight', dpi = 600)


#For the highest_point
table2 = pd.read_excel(r'highest_H.xlsx')    #loading the file

TT = table2['Temp'].values
tt = table2['Hour'].values
yy = table2['year'].values
dd = table2['Julian Day'].values

# Number of sample points
n = len(TT)#70000#60235 #147893
TT = TT[0:n]
N = n
# sample spacing
T = 1 #hours
x = np.linspace(0.0, N*T, N, endpoint=False)
yf= fft(TT)
xf = fftfreq(N, T)[:N//2]

Tmean = np.mean(TT)

ax = plt.figure(figsize=(15,7.5) , dpi=100)
plt.semilogy(xf[1:N//2], 2.0/N * np.abs(yf[1:N//2]), '-b')
plt.ylabel(r'$Amplitude \quad [^oC]$')
plt.xlabel(r'$Frequency \quad [hour^{-1}]$')
plt.title(f"Tmean=%0.2f C, Elevation: 1781m, Year: 2009-17, {N} hour-separated readings"%Tmean)

#x = [1.1621150493e-4,4.1670125342e-2,8.3107827e-2]
#y = [1.4619e1,9.009e-1,1.15571e-1]
x = [1.14504909e-4,4.1665473907e-2,8.333094781e-2]
y = [15.2454,1.14969,1.54781e-1]
plt.plot(x, y, 'kX')

for i_x, i_y in zip(x, y):
    plt.text(i_x, i_y, '({}, {})'.format(i_x, i_y))

plt.grid()
plt.show()
manager = plt.get_current_fig_manager()
manager.window.showMaximized()
plt.tight_layout(pad=0.4, w_pad=0.5, h_pad=1.0)
plt.savefig(f'FFT_David_highest.pdf',bbox_inches='tight', dpi = 600)